package model

type User struct {
	Id int
	Name string
	Department string
	Created string

}



