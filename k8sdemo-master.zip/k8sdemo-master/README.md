# Kubernetes demo application for Go

Other language: 
### **[中文](README.zh.md)**
 
This is an application to show how to deploy a Go application with Kubernetes. 

## Getting Started

#### Download Code

```
go get github.com/jfeng45/k8sdemo
```

## License

[MIT](LICENSE.txt) License


