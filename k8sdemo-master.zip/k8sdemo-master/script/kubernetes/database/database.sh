kubectl apply -f database-volume.yaml
kubectl apply -f database-deployment.yaml
kubectl apply -f database-service.yaml